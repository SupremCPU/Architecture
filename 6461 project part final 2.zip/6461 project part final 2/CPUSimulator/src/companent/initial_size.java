package companent;

public class initial_size {

	public static final int word_size = 16;
	
	
	public static final int mem_word_length = 2048;
	
	
	
}
