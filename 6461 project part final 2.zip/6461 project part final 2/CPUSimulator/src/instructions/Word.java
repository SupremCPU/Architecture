package instructions;

public class Word {

	public int[] data;
	
	public Word(){
		data = new int[16];
	}
	
	public int intValue(){
		return 0;
	}
}
