package frontPanel;

import java.util.LinkedList;
import java.util.Observable;
import java.util.Queue;

public class Log extends Observable{

	
	private static Log _instance;
	public static Log getInstance(){
		if(_instance==null)
			_instance = new Log();
		return _instance;
	}
	
	/*
	 * all message will be stored here
	 * array console message to string list
	 */
	private Queue<String> consoleMessage;
	
	public Log(){
		consoleMessage = new LinkedList<String>();
	}
	
	public void console(String info){
		consoleMessage.add(info);
		
		this.setChanged();
		this.notifyObservers();
	}
	
	public Queue<String> getConsoleMessage() {
		return consoleMessage;
	}
}
