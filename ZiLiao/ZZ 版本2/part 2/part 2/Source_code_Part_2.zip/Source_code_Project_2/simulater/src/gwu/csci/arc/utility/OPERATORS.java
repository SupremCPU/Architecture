package gwu.csci.arc.utility;

public enum OPERATORS {
	add,
	subtract
}
