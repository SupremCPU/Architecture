package edu.gwu.core;

public interface IODevice {

	public void save(int value);
	
	public int getDevid();
}
