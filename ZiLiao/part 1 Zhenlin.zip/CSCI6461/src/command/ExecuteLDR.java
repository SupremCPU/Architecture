package command;

import cpu.Units;
import hardware.Words;
import operation.Instruction;

public class ExecuteLDR extends Execute
{
    public ExecuteLDR(Instruction instr)
    {
        super(instr);
    }

    public void execute(){
        int ea;
        ea = EA();
        int data = Units.memory.getMemory(ea);
        Words reg_data = new Words(data);
        switch(this.instruction.rsr1)
        {
        case 0:
        	Units.r0.setRegister(reg_data);
        	break;
        case 1:
        	Units.r1.setRegister(reg_data);
        	break;
        case 2:
        	Units.r2.setRegister(reg_data);
        	break;
        case 3:
        	Units.r3.setRegister(reg_data);
        	break;
        default:
        	break;
        }
    }
}
