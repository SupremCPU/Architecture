package command;

import cpu.Units;
import hardware.Words;
import operation.Instruction;

public class ExecuteSTR extends Execute
{
    public ExecuteSTR(Instruction instr)
    {
        super(instr);
    }
    public void execute(){
        int ea;
        ea = EA();   
        Words data = new Words();
        switch(this.instruction.rsr1)
        {
        case 0:
        	data = Units.r0.getRegister();
        	break;
        case 1:
        	data = Units.r1.getRegister();
        	break;
        case 2:
        	data = Units.r2.getRegister();
        	break;
        case 3:
        	data = Units.r3.getRegister();
        	break;
        default:
        	break;
        }
        Units.mar.setRegister(new Words(this.instruction.address));
        Units.mdr.setRegister(data);
        Units.memory.StoreMemory();
    }
}
