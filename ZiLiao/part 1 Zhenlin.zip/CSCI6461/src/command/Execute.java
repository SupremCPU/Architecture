package command;

import cpu.Units;
import operation.Instruction;

public abstract class Execute
{
    public Instruction instruction;
    public Execute(Instruction instr){
        instruction = instr;
    }
    public abstract void execute();
    public int EA(){
        int ea;
        
        if (instruction.iTag == 0) {
            if (instruction.ixTag ==0) {
                ea = instruction.address;
            } else {
                ea = Units.x0.getRegister().getWord() + instruction.address;
            }
        } else {
            if (instruction.ixTag == 0){
                ea = Units.memory.getMemory(instruction.address);
            } else {
                ea = Units.memory.getMemory(Units.x0.getRegister().getWord() + instruction.address);
            }
        }
        
        return ea;
    }
    
    
}
