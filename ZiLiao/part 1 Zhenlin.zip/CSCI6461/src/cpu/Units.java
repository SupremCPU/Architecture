package cpu;

import hardware.Memory;
import hardware.Register16;
import hardware.Register8;
import hardware.Register4;

public class Units
{
	public static Register16 pc;// 12bits
	public static Register4 cc;
	public static Register16 ir;	
    public static Register16 mar;
    public static Register16 mdr;
    public static Register16 x0;
    public static Register16 x1;
    public static Register16 x2;
    public static Memory memory;
    public static Register16 r0;
    public static Register16 r1;
    public static Register16 r2;
    public static Register16 r3;
    public static void initializeUnits(){
    	pc = new Register16();
    	ir = new Register16();	
    	cc = new Register4();
        mar = new Register16();
        mdr = new Register16();
        x0 = new Register16();
        x1 = new Register16();
        x2 = new Register16();
        memory = new Memory();
        r0 = new Register16();
        r1 = new Register16();
        r2 = new Register16();
        r3 = new Register16();
    }
}
