package operation;

public class Instruction {

	/*
	 * opcode is the value of an instruction's opcode.
	 * The opcode integer determination is in the OpCode class.
	 */
	public int opcode;
	/*
	 * rsr1 is the source 1 register index number.
	 * rsr2 is the source 2 register index number.
	 */
	public int rsr1;
	public int rsr2;
	/*
	 * iTag the indirect tag. If indirect then iTag = 1, else iTag = 0.
	 */
	public int iTag;
	/*
	 * ixTag the index tag. If index then ixTag = 1, else ixTag = 0.
	 */
	public int ixTag;
	/*
	 * address is the value of address of Load/Store type instructions.
	 * it is also the value of immediate of I-Type instruction.
	 */
	public int address;
	/*
	 * instrString is the instruction's name, used for toString
	 */
	public String instrString;
	/*
	 * instrType is the instruction's type:
	 * R-type, I-type, Load/Store instruction, Transfer instruction and other.
	 */
	public int instrType;
	

	public Instruction(){
		opcode = OpCode.HLT;		
	}
	
	public String toString(){
		return instrString;
	}
	
}
