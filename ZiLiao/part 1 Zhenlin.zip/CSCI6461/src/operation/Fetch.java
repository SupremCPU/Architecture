package operation;

import hardware.Register16;
import hardware.Words;
import cpu.*;

public class Fetch
{	
	public Fetch()
	{
		
	}
	public static void pcToMar()
	{
		Units.mar = Units.pc;
	}
	public static void fetchMarToMdr()
	{
		Units.mdr.setRegister(new Words(Units.memory.getMemory(Units.mar.getRegister().getWord())));
	}
	public static void mdrToIr()
	{
		Units.ir.setRegister(Units.mdr.getRegister());
	}
}