package operation;
/*
 * 
 * The OpCode class set the OpCode with the number.
 *
 */
public class OpCode {
	public static final int HLT = 0;
	public static final int TRAP = 30;
	public static final int LDR = 1;
	public static final int STR = 2;
	public static final int LDA = 3;
	
}
