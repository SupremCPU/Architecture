package hardware;

public class Register8
{

}