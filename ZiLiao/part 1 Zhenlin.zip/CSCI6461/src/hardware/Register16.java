package hardware;

public class Register16 {
    private Words content;
    
    public Register16()
    {
        content=new Words();
    }
    
    public Words getRegister()
    {
        //return new Words(content.getWord());
    	return this.content;
    }
    public boolean setRegister(Words word)
    {
        if(content.setWord(word.getWord()))
            return true;
        else 
            return false;
    }

}
